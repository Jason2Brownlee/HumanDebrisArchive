
Ecosystem quake2 Modification

Jason Brownlee - hop_cha@hotmai.com
April 2003


Requires: Quake II, Quake II Patch 3.20

1. Unzip into your quake 2 directory, eg: c:\quake2\
2. Start the modification: quake2.exe +set game ecosystem +map env1
3. use F1 to spawn a starterkit of agents, or F2 to remove all agents

ecosystem\agents.ini 
Contains all user adjustable constants. These
are reloaded each time a new map is loaded.
